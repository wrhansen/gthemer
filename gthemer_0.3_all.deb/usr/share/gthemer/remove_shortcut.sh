#!/bin/bash
rm -f /usr/bin/gthemer
