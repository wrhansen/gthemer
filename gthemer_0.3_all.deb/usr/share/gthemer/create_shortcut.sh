#!/bin/bash
ln -s /usr/share/gthemer/gthemer /usr/bin/gthemer
